<?php
session_start();

// Connexion automatique hardcodée
$admin_nom = "admin";
$admin_mdp = "12345";

// Vérifier si l'admin est déjà connecté
if (!isset($_SESSION['admin'])) {
    // Si le formulaire est soumis
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nom']) && isset($_POST['mdp'])) {
        if ($_POST['nom'] === $admin_nom && $_POST['mdp'] === $admin_mdp) {
            $_SESSION['admin'] = $admin_nom;
        } else {
            echo "<script>alert('Nom ou mot de passe incorrect');</script>";
        }
    }

    // Afficher le formulaire
    if (!isset($_SESSION['admin'])) {
        echo '
        <!DOCTYPE html>
        <html lang="fr">
        <head><meta charset="UTF-8"><title>Connexion Admin</title></head>
        <body style="font-family: sans-serif; padding: 50px; background-color: #eef7ff;">
            <h2>Connexion Administrateur</h2>
            <form method="POST" style="max-width: 300px;">
                <label>Nom d\'utilisateur :</label><br>
                <input type="text" name="nom" class="form-control" required><br>
                <label>Mot de passe :</label><br>
                <input type="password" name="mdp" class="form-control" required><br><br>
                <button type="submit" class="btn btn-primary">Se connecter</button>
            </form>
        </body>
        </html>';
        exit;
    }
}

// Connexion base de données
$conn = new mysqli("localhost", "root", "", "cdp1");
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}
$result = $conn->query("SELECT * FROM user");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Panneau Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-4">
    <div class="container">
        <h2 class="mb-4">👑 Liste des utilisateurs</h2>
        <table class="table table-bordered table-striped bg-white">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Sexe</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= htmlspecialchars($row['nom']); ?></td>
                    <td><?= htmlspecialchars($row['email']); ?></td>
                    <td><?= htmlspecialchars($row['contact']); ?></td>
                    <td><?= htmlspecialchars($row['sexe']); ?></td>
                    <td>
                        <form action="voir.php" method="POST" style="display:inline">
                            <input type="hidden" name="id" value="<?= $row['id']; ?>">
                            <button class="btn btn-success btn-sm">Voir</button>
                        </form>
                        <form action="modifier.php" method="POST" style="display:inline">
                            <input type="hidden" name="id" value="<?= $row['id']; ?>">
                            <button class="btn btn-warning btn-sm text-dark">Modifier</button>
                        </form>
                        <form action="supprimer.php" method="POST" style="display:inline" onsubmit="return confirm('Supprimer cet utilisateur ?');">
                            <input type="hidden" name="id" value="<?= $row['id']; ?>">
                            <button class="btn btn-danger btn-sm">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php $conn->close(); ?>
