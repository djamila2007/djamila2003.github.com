<?php
session_start();
if (!isset($_SESSION['email_connecte'])) {
    header("Location: login4.php"); // ou la page de login
    exit;
}

$conn = new mysqli("localhost", "root", "", "cdp1");
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

$email = $_SESSION['email_connecte'];
$sql = "SELECT nom, email, sexe, contact, mdp_hache FROM user WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$profil = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon Profil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #007BFF;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 600px;
            margin: 30px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #007BFF;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            font-weight: bold;
            display: block;
        }
        input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        button, a {
            display: inline-block;
            margin-top: 20px;
            background-color: #007BFF;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        button:hover, a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <h1>Mon Profil</h1>
    </header>
    <div class="container">
        <h2>Bienvenue, <?= htmlspecialchars($profil['nom']) ?> !</h2>
        <form method="POST" action="modifier_profil.php" id="profilForm">
            <div class="form-group">
                <label>Nom :</label>
                <input type="text" name="nom" value="<?= htmlspecialchars($profil['nom']) ?>" disabled>
            </div>
            <div class="form-group">
                <label>Email :</label>
                <input type="email" name="email" value="<?= htmlspecialchars($profil['email']) ?>" readonly>
            </div>
            <div class="form-group">
                <label>Sexe :</label>
                <input type="text" name="sexe" value="<?= htmlspecialchars($profil['sexe']) ?>" disabled>
            </div>
            <div class="form-group">
                <label>Contact :</label>
                <input type="text" name="contact" value="<?= htmlspecialchars($profil['contact']) ?>" disabled>
            </div>
            <div class="form-group">
                <label>Mot de passe (haché) :</label>
                <input type="text" name="mdp_hache" value="<?= htmlspecialchars($profil['mdp_hache']) ?>" disabled>
            </div>
            <button type="button" onclick="modifier()">Modifier</button>
            <button type="submit" id="enregistrerBtn" style="display:none;">Enregistrer</button>
        </form>
        <a href="accueil5.html">Retour au tableau de bord</a>
    </div>

    <script>
        function modifier() {
            const champs = document.querySelectorAll('#profilForm input:not([readonly])');
            champs.forEach(champ => champ.disabled = false);
            document.getElementById('enregistrerBtn').style.display = 'inline-block';
        }
    </script>
</body>
</html>
