<?php
session_start();

// Vérifie que le code et l'email ont été enregistrés en session
if (!isset($_SESSION['email_a_valider']) || !isset($_SESSION['code_a_valider'])) {
    echo "<script>alert('Aucune inscription en attente de validation.'); window.location.href='index.php';</script>";
    exit;
}

// Si le formulaire de validation est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code_saisi = $_POST['code_validation'];
    $email = $_SESSION['email_a_valider'];
    $code_attendu = $_SESSION['code_a_valider'];

    if ($code_saisi == $code_attendu) {
        // Connexion à la base de données
        $conn = new mysqli("localhost", "root", "", "cdp1");

        if ($conn->connect_error) {
            die("Connexion échouée : " . $conn->connect_error);
        }

        // Mettre à jour la validation de l'utilisateur
        $stmt = $conn->prepare("UPDATE user SET valide = 1 WHERE email = ?");
        if (!$stmt) {
            die("Erreur de préparation de la requête : " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        if ($stmt->execute()) {
            // Nettoyer la session
            unset($_SESSION['email_a_valider']);
            unset($_SESSION['code_a_valider']);

            echo "<script>alert('Compte validé avec succès. Vous pouvez maintenant vous connecter.'); window.location.href='login4.php';</script>";
            exit;
        } else {
            echo "<script>alert('Erreur lors de la validation.');</script>";
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "<script>alert('Code de validation incorrect.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation du Code</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="card-title mb-4">Entrez le code de validation reçu</h3>
                        <form method="post">
                            <div class="mb-3">
                                <label for="code_validation" class="form-label">Code de validation</label>
                                <input type="text" class="form-control" id="code_validation" name="code_validation" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Valider le compte</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
