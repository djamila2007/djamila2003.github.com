<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connexion à la base de données
    $host = "sql113.infinityfree.com";
    $user = "if0_39018401";
    $password = "KUih1MaXFd";
    $dbname = "if0_39018401_dbuser";

    $conn = new mysqli($host, $user, $password, $dbname);

    if ($conn->connect_error) {
        die("Connexion échouée : " . $conn->connect_error);
    }

    // Récupérer les données du formulaire
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $mdp = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $contact = $_POST['contact'];
    $sexe = $_POST['sexe'];

    // Générer un code de validation aléatoire
    $code_validation = rand(100000, 999999);

    // Vérifier si l'email existe déjà
    $verif = $conn->prepare("SELECT * FROM user WHERE email = ?");
    $verif->bind_param("s", $email);
    $verif->execute();
    $result = $verif->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Cet email est déjà utilisé.'); window.location.href='index.php';</script>";
        exit;
    }

    // Insérer l'utilisateur avec le code de validation
    $stmt = $conn->prepare("INSERT INTO user (nom, email, mdp_hache, contact, sexe, code_validation, valide) VALUES (?, ?, ?, ?, ?, ?, 0)");
    if (!$stmt) {
        die("Erreur de préparation : " . $conn->error);
    }

    $stmt->bind_param("sssssi", $nom, $email, $mdp, $contact, $sexe, $code_validation);
    $stmt->execute();

    // Sauvegarder les infos en session
    $_SESSION['email_a_valider'] = $email;
    $_SESSION['code_a_valider'] = $code_validation;

    // Envoi de l'e-mail avec PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Config SMTP Gmail
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'barradjamila2@gmail.com'; // Ton email Gmail
        $mail->Password = 'xxskkmolqxilnaec'; // Mot de passe d'application
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Expéditeur et destinataire
        $mail->setFrom('barradjamila2@gmail.com', 'BMD Appli'); // À modifier avec ton nom/domaine
        $mail->addAddress($email, $nom);

        // Contenu du mail
        $mail->isHTML(true);
        $mail->Subject = 'Votre code de validation';
        $mail->Body = "Bonjour <strong>$nom</strong>,<br><br>Voici votre code de validation : <strong>$code_validation</strong><br><br>Merci de le saisir sur le site pour finaliser votre inscription.<br><br><em>L’équipe BMD</em>";
        $mail->AltBody = "Bonjour $nom,\n\nVoici votre code de validation : $code_validation\n\nMerci de le saisir sur le site.";

        $mail->send();

        echo "<script>alert('Inscription presque réussie. Un email contenant le code de validation a été envoyé à votre adresse.'); window.location.href='valider_code3.php';</script>";
        exit;
    } catch (Exception $e) {
        echo "<script>alert('L\'email n\'a pas pu être envoyé. Erreur : {$mail->ErrorInfo}'); window.location.href='index.php';</script>";
    }
}
?>
