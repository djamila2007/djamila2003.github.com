<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connexion à la base de données
    $conn = new mysqli("localhost", "root", "", "cdp1");

    if ($conn->connect_error) {
        die("Connexion échouée : " . $conn->connect_error);
    }

    $email = $_POST['email'];
    $mdp = $_POST['password'];

    // Vérifier si l'utilisateur existe
    $stmt = $conn->prepare("SELECT mdp_hache, valide FROM user WHERE email = ?");
    if (!$stmt) {
        die("Erreur de préparation : " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // Vérifie si l'utilisateur existe
    if ($stmt->num_rows == 1) {
        $stmt->bind_result($mdp_hache, $valide);
        $stmt->fetch();

        // Vérifie le mot de passe
        if (password_verify($mdp, $mdp_hache)) {
            if ($valide == 1) {
                // Connexion réussie
                $_SESSION['email_connecte'] = $email;
                echo "<script>alert('Connexion réussie !'); window.location.href='accueil5.html';</script>";
                exit;
            } else {
                echo "<script>alert('Votre compte n’est pas encore validé. Veuillez saisir le code de validation.'); window.location.href='valider_code3.php';</script>";
                exit;
            }
        } else {
            echo "<script>alert('Mot de passe incorrect.');</script>";
        }
    } else {
        echo "<script>alert('Aucun compte trouvé avec cet email.');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="card-title mb-4">Connexion à votre compte</h3>
                        <form method="post">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" name="email" id="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Mot de passe</label>
                                <input type="password" class="form-control" name="password" id="password" required>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mt-4">
                                <button type="submit" class="btn btn-primary">Se connecter</button>
                                <a href="#" class="text-decoration-none small">Mot de passe oublié?</a>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="text-center mt-3">
                    <p class="small text-muted">Vous n'avez pas de compte? <a href="#" class="text-decoration-none">Inscrivez-vous</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
