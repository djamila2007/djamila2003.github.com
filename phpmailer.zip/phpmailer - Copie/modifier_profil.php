<?php
session_start();
if (!isset($_SESSION['email_connecte'])) {
    header("Location: profil.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "cdp1");
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

$email = $_POST['email']; // L'email ne change pas
$nom = $_POST['nom'];
$sexe = $_POST['sexe'];
$contact = $_POST['contact'];

$sql = "UPDATE user SET nom=?, sexe=?, contact=? WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $nom, $sexe, $contact, $email);

if ($stmt->execute()) {
    echo "<script>alert('Profil mis à jour avec succès !'); window.location.href='profil.php';</script>";
} else {
    echo "<script>alert('Erreur lors de la mise à jour du profil.'); window.location.href='profil.php';</script>";
}
$stmt->close();
$conn->close();
?>
